import { GoogleGenerativeAI } from "./genai.js";
const API_KEY = "AIzaSyBml9UEzPtxJggDdnyqvWA2vZuV3Owq7d0";
const genAI = new GoogleGenerativeAI(API_KEY);

async function sendRequestWithDelay(userPrompt, questionIndex) {
    try {
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const result = await model.generateContent(`${userPrompt} without explanation just correct answer`);
        const response = await result.response;
        const text = await response.text(); // Получаем правильный ответ

        // Вставляем правильный ответ на активную вкладку
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            const tab = tabs[0];
            if (tab) {
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: insertCorrectAnswer,
                    args: [text.trim(), questionIndex] // Передаем правильный ответ и индекс вопроса
                });
            }
        });
    } catch (error) {
        if (error.response && error.response.status === 429) {
            console.error("Too many requests. Retrying...");
            await new Promise(resolve => setTimeout(resolve, 5000));
            sendRequestWithDelay(userPrompt, questionIndex);
        } else {
            console.error("Error:", error);
        }
    }
}

const clickBtn = document.getElementById("clickButton");
clickBtn.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        if (tab) {
            execScript(tab);
        } else {
            alert("There are no active tabs");
        }
    });
});

function execScript(tab) {
    chrome.scripting.executeScript(
        {
            target: { tabId: tab.id },
            func: findQuestionsAndAnswers
        },
        onResult
    );
}

function findQuestionsAndAnswers() {
    const questions = document.querySelectorAll(".test-question");
    const results = Array.from(questions).map((question) => {
        const questionText = question.textContent.trim();
        const answers = Array.from(
            question.closest(".test-table").querySelectorAll(".test-answers > li > label")
        ).map(label => label.textContent.trim());

        return {
            question: questionText,
            answers: answers
        };
    });

    return results;
}

function onResult(frames) {
    if (!frames || frames.length === 0 || !frames[0].result) {
        const errorDiv = document.createElement("div");
        errorDiv.textContent = "No questions or answers found with the given structure.";
        errorDiv.style.color = "red";
        document.body.appendChild(errorDiv);
        return;
    }

    const results = frames[0].result;

    // Отправляем запросы для каждого вопроса, передавая индекс
    results.forEach((result, index) => {
        const userPrompt = `Question: ${result.question}\nAnswers: ${result.answers.join(", ")}`;
        sendRequestWithDelay(userPrompt, index); // Передаем индекс вопроса
    });
}

function insertCorrectAnswer(correctAnswerText, questionIndex) {
    // Извлекаем первую букву правильного ответа (например, из "a rises" получаем "a")
    const match = correctAnswerText.match(/^(\w)/); // Находим первую букву в строке
    const correctAnswer = match ? match[1].trim() : ''; // Извлекаем первую букву

    // Найдем все вопросы на странице
    const questionElements = document.querySelectorAll(".test-question");

    // Найдем нужный вопрос по индексу
    const questionElement = questionElements[questionIndex];

    if (questionElement) {
        // Находим все варианты ответов для текущего вопроса
        const answerElements = questionElement.closest(".test-table").querySelectorAll(".test-answers > li > label");

        // Проходим по каждому варианту ответа и проверяем на совпадение с правильным ответом
        answerElements.forEach((answerElement) => {
            const answerText = answerElement.textContent.trim();

            // Проверяем, совпадает ли первая буква ответа с правильной буквой
            if (answerText.startsWith(correctAnswer)) {
                // answerElement.style.color = "green"; // Если совпадает, выделяем цветом
                answerElement.onmouseenter = () => {
                    answerElement.style.color = 'green';
                    answerElement.style.cursor = 'pointer';
                };

                // Убираем эффект при уходе курсора
                answerElement.onmouseleave = () => {
                    answerElement.style.color = 'black';
                    answerElement.style.cursor = 'default';
                };
            }
        });

    }
}